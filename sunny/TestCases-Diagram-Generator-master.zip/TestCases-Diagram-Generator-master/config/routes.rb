Rails.application.routes.draw do
  get '/diagrams', to: 'diagrams#show'
  get '/get_diagram', to: 'diagrams#get_diagram', via: [:get]
  get '/get_diagram_png', to: 'diagrams#get_diagram'
end
