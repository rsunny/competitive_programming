class DiagramsController < ApplicationController
  def show
    render template: 'diagrams/show'
  end

  def get_diagram
    # ans=system("dot -Tpng /Users/Aakansha/Documents/Work-Projects/rails_projects/TestCases-Diagram-Generator/app/templates/directed_graoh/directed_graph_head.dot > /Users/Aakansha/Documents/Work-Projects/rails_projects/TestCases-Diagram-Generator/app/templates/output.png")
    # puts ans
    require '/Users/Aakansha/Documents/Work-Projects/rails_projects/TestCases-Diagram-Generator/app/templates/parser.rb'
    datatype = params[:datatype]
    testcase = params[:testcase]
    output_type = params[:choice]
    parser = Parser.new(datatype, testcase)
    final_testcase = parser.parse_data
    merge_head_body_tail datatype, final_testcase
    render layout: false, template: 'diagrams/get_diagram',locals: {choice: output_type}
  rescue Exception => e
    puts e.message
  end

  def merge_head_body_tail(datatype, testcase)

    file_prefix=datatype
    if file_prefix.include?"linked_list"
      file_prefix="linked_list"
    end

    if file_prefix.include?"undirected"
      file_prefix="undirected_graph"
    elsif file_prefix.include?"directed"
      file_prefix="directed_graph"
    end

    head = File.open('/Users/Aakansha/Documents/Work-Projects/rails_projects/TestCases-Diagram-Generator/app/templates/' + file_prefix + '/' + file_prefix + '_head.dot', 'r').read
    tail =  File.open('/Users/Aakansha/Documents/Work-Projects/rails_projects/TestCases-Diagram-Generator/app/templates/' + file_prefix + '/' + file_prefix + '_tail.dot', 'r').read
    case datatype
      when "array"
        input = []
        testcase.each_with_index do |i, index|
          input[index] = '<' + index.to_s + '>' + i.to_s
        end
        indexes = []
        testcase.length.times do |i|
          indexes[i] = '<' + i.to_s + '>' + i.to_s
        end
        input = input.join(' | ')
        array_index = indexes.join(' | ')
        body = "\tnode1 [label =\"#{input}\"];\n\tnode [shape=record,color=white];\n\t\nnode2 [label =\"#{array_index}\"];"
        tail_pre=[]
        testcase.length.times do |i|
          tail_pre[i]="\tnode2:<"+i.to_s+">->node1:<"+i.to_s+">"
        end
        tail_pre=tail_pre.join("\n")
        body= body+tail_pre
      when "stack"
        input = []
        testcase.each_with_index do |i, index|
          input[index] = '<' + index.to_s + '>' + i.to_s
        end
        indexes = []
        testcase.length.times do |i|
          current_index=testcase.length-i-1
          indexes[i] = '<' + i.to_s + '>' + current_index.to_s
        end
        input = input.join(' | ')
        array_index = indexes.join(' | ')
        body = "\tnode1 [label =\"#{input}\"];\n\tnode [shape=record,color=white];\n\t\nnode2 [label =\"#{array_index}\"];"
        tail_pre=[]
        testcase.length.times do |i|
          tail_pre[i]="\tnode2:<"+i.to_s+">->node1:<"+i.to_s+">"
        end
        tail_pre=tail_pre.join("\n")
        body= body+tail_pre
      when "singly_linked_list", "doubly_linked_list", "circular_linked_list"
        tail_pre = testcase.join("\t->")
        tail_pre+="\n"
        if datatype.eql?"doubly_linked_list"
          tail_pre_reverse = testcase.reverse.join("\t->")
          tail_pre+=tail_pre_reverse
        end
        if datatype.eql?"circular_linked_list"
          tail_pre+="\n\t"+testcase[testcase.length-1]+"->"+testcase[0]
        end
        body = tail_pre
      when "undirected_graph"
        input = testcase.join("\t\n")
        body=input.gsub(' ',' -- ')
      when "directed_graph"
        input = testcase.join("\t\n")
        body = input.gsub(' ','->')
      when "undirected_weighted_graph"
        input =[]
        testcase.each do |p|
          v1,v2,weight=p.split(" ")
          input << v1+" -- "+ v2+"[label="+weight+",weight="+weight+"]"
        end
        body = input.join("\t\n")
      when "directed_weighted_graph"
        input =[]
        testcase.each do |p|
          v1,v2,weight=p.split(" ")
          input << v1+" -> "+ v2+"[label="+weight+",weight="+weight+"]"
        end
        body = input.join("\t\n")
    end
    code = head + body + tail
    file = File.open('temp/diagram.dot', 'w')
    file.write(code)
    file.close
    system('dot -Tsvg /Users/Aakansha/Documents/Work-Projects/rails_projects/TestCases-Diagram-Generator/temp/diagram.dot > /Users/Aakansha/Documents/Work-Projects/rails_projects/TestCases-Diagram-Generator/app/views/diagrams/_output.html.erb')
    system('dot -Tpng /Users/Aakansha/Documents/Work-Projects/rails_projects/TestCases-Diagram-Generator/temp/diagram.dot > /Users/Aakansha/Documents/Work-Projects/rails_projects/TestCases-Diagram-Generator/app/assets/images/diagram.png')

    puts 'Graph create'
  end
end
