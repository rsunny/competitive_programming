class Parser
  def initialize(datatype, testcase)
    @datatype=datatype
    @testcase=testcase
  end

  def parse_data
    current_datatype = @datatype
    current_testcase = @testcase
    puts(current_datatype+"---------"+current_testcase)
    ##binding.pry
    case current_datatype
    when "array", "stack", "singly_linked_list", "doubly_linked_list", "circular_linked_list", "circular_linked_list"
      input_array = current_testcase.split("\n")
      size = input_array[0].to_i
      input_array=input_array[1..size]
      final_testcase=input_array.dup
    when  "undirected_graph", "directed_graph", "undirected_weighted_graph", "directed_weighted_graph"
      #binding.pry
      input_array = current_testcase.split("\n")
      nodes,edges = input_array[0].split(" ").map(&:to_i)
      final_testcase = input_array[1..edges]
    return final_testcase
    end
  end
end
