## TestCase Diagram Generator
This app helps to generate diagrams of the below data structures based on the test cases with help of [Graphviz](http://www.graphviz.org/)
. More support will be added for more data structures
* Arrays
* Stack
* Single Linked List
* Doubly Linked List
* Circular Linked List
* Directed Graph
* Undirected Graph
* Directed Weighted Graph
* Undirected Weighted Graph

This app generates the diagram with the help of [dot](http://www.graphviz.org/doc/info/lang.html) language.

### Installation Instructions

* Clone the project

```
git clone git@github.com:ad1992/TestCases-Diagram-Generator.git

```
* Create a file named as database.yml. A sample file database.yml.example has already been provided.

* bundle install

* rails s

* Now you are all set. Type the below url in your browser

```
http://localhost:3000/diagrams

```

### Issues
If you find any issue, please open an issue [here](https://github.com/ad1992/TestCases-Diagram-Generator/issues)

### Contributions

If you want to contribute, please fork this project and open a pull request.


### Below are some screen shots attached

<img width="1280" alt="screen shot 2017-01-25 at 1 26 48 am" src="https://cloud.githubusercontent.com/assets/11256141/22264400/d3f42ba8-e29d-11e6-80a4-353d70d04b5b.png">
<img width="1280" alt="screen shot 2017-01-25 at 1 27 11 am" src="https://cloud.githubusercontent.com/assets/11256141/22264402/d3f98a9e-e29d-11e6-9efc-8b189ae14eac.png">
<img width="1280" alt="screen shot 2017-01-25 at 1 27 25 am" src="https://cloud.githubusercontent.com/assets/11256141/22264403/d4009bea-e29d-11e6-84ba-f0a099b5941a.png">
<img width="1280" alt="screen shot 2017-01-25 at 1 28 26 am" src="https://cloud.githubusercontent.com/assets/11256141/22264404/d404b0ae-e29d-11e6-892e-b6d1149f228c.png">
<img width="1280" alt="screen shot 2017-01-25 at 1 28 33 am" src="https://cloud.githubusercontent.com/assets/11256141/22264405/d4085a38-e29d-11e6-9511-7ecc6aa87eda.png">
<img width="1280" alt="screen shot 2017-01-25 at 1 28 54 am" src="https://cloud.githubusercontent.com/assets/11256141/22264401/d3f9ac68-e29d-11e6-9349-5f8a6b865402.png">
<img width="1280" alt="screen shot 2017-01-25 at 1 28 58 am" src="https://cloud.githubusercontent.com/assets/11256141/22264406/d4247a60-e29d-11e6-96d6-b148d7f54a9f.png">
<img width="1280" alt="screen shot 2017-01-25 at 1 29 08 am" src="https://cloud.githubusercontent.com/assets/11256141/22264407/d429f724-e29d-11e6-91de-40562f999c35.png">
<img width="1280" alt="screen shot 2017-01-25 at 1 29 13 am" src="https://cloud.githubusercontent.com/assets/11256141/22264408/d43f0d8a-e29d-11e6-93c7-3616ec87cb19.png">
